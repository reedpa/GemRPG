RPG Icon Pack 1 - Items and Skills
by 7Soul - @7SoulDesign
http://7soul1.deviantart.com/

v1.0
1394 Icons Total
96 Armors
24 Boots
72 Helmets
32 Accessories
64 Monster Drops
48 Foods
100 Materials
48 Pills
224 Potions
216 Quest Items
90 Rings
40 Shields
152 Skills
192 Weapons

v1.1
114 Icons Total
36 Gloves
30 Skills
48 Weapons

v1.1b
Fixed some errors

v1.1c
Fixed some missing border pixels from some accessories and a banana
Added a sprite sheet containing all icons

v1.1d
Fixed some icons being exported with the wrong color mode
Added missing 'broken potions' icons from pack A

v1.2
Folder "Renamed" has renamed icons for better ordering and numbering
The "_sheet.png" files had to be reordered regardless, so sprite references will probably break :/

256 New icons:
98 Weapons
80 Skills
24 Foods
16 Rings
13 Accessories
12 Armors
5 Boots
5 Gloves
3 Shields

v1.2.1
Some icons had broken transparency, fixed that